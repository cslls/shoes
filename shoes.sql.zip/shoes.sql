-- phpMyAdmin SQL Dump
-- version 5.1.3
-- https://www.phpmyadmin.net/
--
-- Хост: 127.0.0.1:3306
-- Время создания: Сен 07 2022 г., 12:02
-- Версия сервера: 8.0.29
-- Версия PHP: 7.1.33

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `shoes`
--

-- --------------------------------------------------------

--
-- Структура таблицы `shoes`
--

CREATE TABLE `shoes` (
  `ShoeId` int NOT NULL,
  `ShoeName` varchar(60) NOT NULL,
  `ShoePrice` int NOT NULL,
  `ShoeImage` varchar(60) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `ShoeStars` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Дамп данных таблицы `shoes`
--

INSERT INTO `shoes` (`ShoeId`, `ShoeName`, `ShoePrice`, `ShoeImage`, `ShoeStars`) VALUES
(1, 'Best Shoes', 60, 'shoes-img4', 5),
(2, 'Best Shoes', 400, 'shoes-img5', 5),
(3, 'Best Shoes', 50, 'shoes-img6', 4),
(4, 'Sports Shoes', 70, 'shoes-img7', 1),
(5, 'Sports Shoes', 100, 'shoes-img8', 3),
(6, 'Sports Shoes', 90, 'shoes-img9', 5);

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `shoes`
--
ALTER TABLE `shoes`
  ADD PRIMARY KEY (`ShoeId`);

--
-- AUTO_INCREMENT для сохранённых таблиц
--

--
-- AUTO_INCREMENT для таблицы `shoes`
--
ALTER TABLE `shoes`
  MODIFY `ShoeId` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
